This pack contains very minor lexers, ok lexers are inside Addons Manager "Install" list.
