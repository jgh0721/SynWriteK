Place IniUpdater.exe into folder with "Syn.ini" file,
run it. It splits part of Syn.ini into new SynHistory.ini file.
Needed for SynWrite update 6.0 -> 6.1.
