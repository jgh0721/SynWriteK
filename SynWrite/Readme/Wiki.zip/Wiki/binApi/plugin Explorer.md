**Explorer** panel plugin shows Explorer-like file-manager form inside SynWrite. Its tab is near Tree/Project tabs, you need to show Tree/Project panel first (command "Window -- Panels -- Tree pane").

Plugin has several options, they are accessible via popup menu of "gear" toolbar icon.

Source code ships with SynWrite (in folder "Readme").
