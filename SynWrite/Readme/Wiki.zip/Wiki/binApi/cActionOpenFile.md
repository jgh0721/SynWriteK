This action can be called by plugin to open file in editor.

Parameters:

- **A1** (PWideChar) - full file path to open.
- **A2, A3, A4** - ignored.

Return value can be ignored.
