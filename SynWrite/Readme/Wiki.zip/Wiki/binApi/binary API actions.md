These actions can be called by plugins:

- [cActionOpenFile]
- [cActionOpenFtpFile]
- [cActionGetOpenedFileName]
- [cActionAddToFavorites]
- [cActionGetMsg]
- [cActionControlLog]
- [cActionParseRegex] 
- [cActionSaveFile]
- [cActionShowHint]
- [cActionGetProjectFileName]
- [cActionSetState]

Editor-related actions:

- [cActionSuggestCompletion] 
- [cActionGetCaretPos] 
- [cActionSetCaretPos] 
- [cActionGetText]
- [cActionSetText]
- [cActionGetSelection]
- [cActionSetSelection]
- [cActionGetProperty]
- [cActionSetTopLine]
- [cActionReplaceText]
- [cActionTranslatePos]

These actions can be called by SynWrite:

- [cActionNavigateToFile]
- [cActionRefreshFileList]
- [cActionUpdateLang]
- [cActionRepaint]
- [cActionSaveFtpFile]
- [cActionFindID] 
- [cActionMenuCommand]
- [cActionGetAutoComplete]
- [cActionSetColor]
