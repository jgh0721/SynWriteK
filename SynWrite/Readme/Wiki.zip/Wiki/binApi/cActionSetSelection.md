This action can be called by plugin to set or reset current editor selection position.
Negative value of SelLength structure member resets selection.

Parameters:

- **A1** (PSynSelection) - points to selection position structure. 
- **A2, A3, A4** - not used.

Return value: not used.
