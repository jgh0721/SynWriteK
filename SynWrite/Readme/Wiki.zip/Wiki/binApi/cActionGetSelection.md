This action can be called by plugin to read current editor selection position.

Parameters:

- **A1** (PSynSelection) - points to selection position structure.
- **A2, A3, A4** - not used.

Return value: not used.
