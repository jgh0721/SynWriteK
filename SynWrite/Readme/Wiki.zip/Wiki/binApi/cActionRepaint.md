This action is called by SW to inform panel plugin that panel repaint may be needed.

Paramaters: not used.

Return value: not used.
