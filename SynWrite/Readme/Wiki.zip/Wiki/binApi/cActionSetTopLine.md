This action can be called by plugin to set index of top visible line in current editor.

Parameters:

- **A1** (Integer) - line index.
- **A2, A3, A4** - not used.

Return value: `cSynOK` if valid line index is passed, `cSynError` otherwise.
