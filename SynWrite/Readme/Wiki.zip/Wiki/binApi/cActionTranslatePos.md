This action can be called by plugin to translate text position value: from absolute offset to column/line values, or vice versa.

Parameters:

- **A1** (PInteger) - points to column position (0-based).
- **A2** (PInteger) - points to line position (0-based).
- **A3** (PInteger) - points to absolute offset (0-based).
- **A4** (Bool) - translation direction: True for offset to column/line, False otherwise.

Return value: not used.
