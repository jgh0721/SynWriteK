This action can be called by SW to inform plugin that current interface language has been changed.

Parameters: not used.

Return value: not used.
