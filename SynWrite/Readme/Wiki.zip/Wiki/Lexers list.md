The following lexers (counting only important ones) exist for SynWrite. 
Most of them are not installed by default, they are located in Addons Manager "Install" list.

* ABAP
* Abaqus Keywords
* ABC Notation
* ActionScript
* Acu Cobol
* Ada
* Apache config
* Apache Pig
* AppleScript
* Arduino
* ARM Assembly
* Assembly
* Assembly FASM
* Assembly JWASM
* Asymptote
* AutoHotkey
* AutoIt
* Automake
* AviSynth
* AWK
* Bash script
* Batch files
* BibTeX
* Bitsquid SJSON
* Boo
* Brainfuck
* C
* C#
* C++
* Caml
* Clarion
* Clavier
* Clipper
* Clojure
* CMake
* Cobol
* CodeVisionAVR
* CoffeeScript
* ColdFusion
* CRF files
* CSS
* CUDA C++
* D
* Dart
* Delphi resources
* Diff
* Dockerfile
* Eiffel
* Elm
* Erlang
* Euphoria
* F#
* Factor
* Forth
* Fortran
* FoxPro
* GAMS
* Gherkin
* GLSL
* Go
* Gold Parser
* Graphviz
* Great Cow Basic
* Groovy
* Haml
* Harbour
* Haskell
* Haxe
* HTML
* HTML Diafan
* HTML Embedded JS
* HTML Handlebars
* HTML Laravel Blade
* HTML Mustache
* HTML Siteleaf Liquid
* HTML Smarty
* IDL files
* IDL language
* Informix 4GL
* Ini files
* Inno Setup
* Jade
* Jasmine JVM Assembler
* Java
* Java Velocity
* JavaScript
* JavaScript Babel/ React JSX
* JCL
* Jinja2
* JSON
* Julia
* KiXtart
* LaTeX
* LESS
* Lisp
* Log files
* Lua
* Macro Scheduler script
* Makefile
* Markdown
* MATLAB
* Metafont
* MIB files
* MIPS Assembly
* Modelica
* Modula 2
* MSVS Solution
* MySQL
* Nemerle
* NFO files
* Nginx
* Nim
* nnCron
* NSIS
* NSL Assembler
* Oberon
* Objective-C
* OpenCL
* OpenEdge
* OpenSCAD
* Parser3
* Pascal
* Pawn
* Perl
* PHP
* Pike
* PL/SQL
* PostScript
* PowerShell
* Prolog
* Properties
* Puppet
* Python
* R
* R Markdown
* Ragel
* Razor
* Resource script
* reStructuredText
* RPG/IV
* RTF (RichText)
* Ruby
* Rust
* Sass
* Scala
* Scheme
* SCSS
* Slim
* Smalltalk
* SQL
* Standard ML
* Stata
* Stylus
* Swift
* T-SQL
* Tcl/Tk
* TOML
* Tree
* Twig
* TypeScript
* Vala
* VBScript
* Verilog HDL
* VHDL
* Virgil
* Visual Basic
* Visual dBase
* WinBuilder script
* WSH script
* XML
* XSLT
* Yacc
* YAML 
