SynWrite wiki index:

- [python API]
- [binary API]
- [Plugins automatic installation]
- [Plugins manual installation]
- [Plugins translation]
- [Lexers list]
- [Registry]
- [RegistryVersions]

Misc:

- [Session file format]
- [Emmet update]
- [Lexers states]

To add a new page simply reference it within brackets, [example].
The wiki uses [Markdown](https://sourceforge.net/p/synwrite/wiki/markdown_syntax_dialog/) syntax.
