import sys 
sys.ps1 = "Portable Python >>> " 
